object Q9 {
  def main(arg: Array[String]): Unit = {
    val f1 = (x: Int, y: Int) => x + y
    val f2 = (x: Int, y: Int) => x - y
    println(alternate(f1, f2, List()))
    println(alternate(f1, f2, List(55)))
    println(alternate(f1, f2, List(1, 2)))
    println(alternate(f1, f2, List(1, 2, 3)))
    println(alternate(f1, f2, List(1, 2, 3, 4)))
  }

  def alternate(
      f1: (Int, Int) => Int,
      f2: (Int, Int) => Int,
      list: List[Int]
  ): Int = {
    if (list.isEmpty) 0
    else if (list.length == 1) list.head
    else f1(list.head, alternate(f2, f1, list.tail))
  }

}
