object Q4 {
  def main(arg: Array[String]): Unit = {
    val l = List(3, 1, 4, 2, 5)
    println(mergesort(l))
  }

  def mergesort(list: List[Int]): List[Int] = {
    if (list.length <= 1) return list
    val (a, b) = split(list, List(), list.length / 2);
    merger(mergesort(a), mergesort(b), List())
  }

  def split(a: List[Int], b: List[Int], count: Int): (List[Int], List[Int]) = {
    if (count == 0) return (a, b)
    else return split(a.tail, b ++ List(a.head), count - 1)
  }

  def merger(a: List[Int], b: List[Int], c: List[Int]): List[Int] = {
    if (a.isEmpty && b.isEmpty) return c
    if (a.isEmpty) return c ++ b
    if (b.isEmpty) return c ++ a
    if (a.head < b.head) return merger(a.tail, b, c ++ List(a.head))
    else return merger(a, b.tail, c ++ List(b.head))
  }
}
