object Q8 {
  def main(arg: Array[String]): Unit = {
    println(sumAll(List()))
    println(sumAll(List(List())))
    println(
      sumAll(
        List(List(1, 2, 3, 4), List(), List(4, 5), List(1, 2, 3, 4, 5, 6))
      )
    )
    println(
      sumAll(
        List(List(3, 4), List(1, 2, 3, 4, 5, 6), List(1, 2, 3, 4))
      )
    )
    println(
      sumAll(
        List(
          List(1, 2, 3, 4, 5, 6),
          List(1, 2, 3, 4),
          List(1, 2),
          List(0, 0, 0, 0, 0, 0, 0, 0, 9)
        )
      )
    )
  }

  def sumAll(lists: List[List[Int]]): List[Int] = {
    sumAcc(lists, List())
  }

  def sumAcc(list2: List[List[Int]], acc: List[Int]): List[Int] = {
    if (list2.isEmpty) return acc
    return sumAcc(list2.tail, sumList(list2.head, acc))
  }
  def sumList(a: List[Int], b: List[Int]): List[Int] = {
    if (a.isEmpty && b.isEmpty) return List()
    if (a.isEmpty) return b
    if (b.isEmpty) return a
    return a.head + b.head :: sumList(a.tail, b.tail)
  }

}
