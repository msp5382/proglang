object Q9 {
  def main(arg: Array[String]): Unit = {
    val tape = List('C', 'H', 'A', 'R')
    val f1 = (x: Char) => x.toLower
    println(turingStep(f1, tape, 2))
    println(turingStep(f1, tape, 3))
    println(turingStep(f1, tape, 0))
    println(turingStep(f1, tape, 5))
  }

  def turingStep(f: Char => Char, tape: List[Char], n: Int): List[Char] = {
    if (n <= 0 || tape.isEmpty) tape
    else f(tape.head) :: turingStep(f, tape.tail, n - 1)
  }

}
